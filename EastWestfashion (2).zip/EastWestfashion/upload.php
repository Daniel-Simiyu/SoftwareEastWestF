<!DOCTYPE html>
<html lang="en">
<head>
<title>Upload</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="css/project.css">

    <!-- Load an icon library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	 <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700&display=swap" rel="stylesheet">


	  <style>
    
    	input, button{
    		font-family: 'Nunito', sans-serif;
    		font-weight: 700;
    	}
    	.main-div{
    		width:25%;
    		margin:0px auto;
    		margin-top: 20px;
    		padding:20px;
    	}

    	.main-div input{
    		display:block;
    		border:1px solid #ccc;
    		border-radius: 5px;
    		background: #fff;
    		padding:15px;
    		outline:none;
    		width:100%;
    		margin-bottom: 20px;
    		transition: 0.3s;
    		-webkit-transition: 0.3s;
    		-moz-transition: 0.3s;
    	}

    	.main-div input:focus {
    		border: 1px solid #777;
    	}

    	.main-div button{
    		background: #5d8ffc;
    		color: #fff;
    		border: 1px solid #5d8ffc;
    		border-radius: 5px;
    		padding: 15px;
    		display: block;
    		width:100%;
    		transition: 0.3s;
    		-webkit-transition: 0.3s;
    		-moz-transition: 0.3s;
    	}

    	.main-div button:hover{
    		background: #fff;
    		color: #5d8ffc;
    		border: 1px solid #5d8ffc;
    		cursor: pointer;

    	}
    </style>
</head>
<body>

<div class="super_container">
<header class="header">
		<div class="header_inner d-flex flex-row align-items-center justify-content-start">
			<div class="logo"><a href="#">EW FASHION</a></div>
			<nav class="main_nav" >
				<ul>
					<li><a href="#">dashboard</a></li>
					<li><a href="#"></a></li>
					<li><a href="#"></a></li>
				</ul>
			</nav>
			<div class="header_content ml-auto">
				
				<div class="shopping">
						<!-- Avatar -->
					<a href="#">
						<div class="avatar">
							<img src="images/avatar.png" alt="">
						</div>
					</a>
				</div>
			</div>

			
		</div>
	</header>

	<div class="section_title_container text-center" style="margin-top: 130px !important;">
		<div class="section_title" >UPLOAD ITEM</div>	
	</div>
			
		<div class="main-div">
            <form action="#" method="POST" enctype="multipart/form-data">
            <label >Product:</label>
  			<input type="text"  name="product"/>
  			<label >Quantity:</label><br>
  			<input type="number"  name="quantity"/>
  			<label >Price:</label><br>
  			<input type="number"  name="price"/>
  			<label >Upload Photo:</label><br>
  			<input type="file"  name="fileToUpload">
  			<button type="submit" name="upload">Add Item</button>
        </form>
  		</div>
	

	

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col text-center">
					<div class="footer_logo"><a href="#">EastWestFashion</a></div>
					<nav class="footer_nav">
							<ul>
							<li><a href="">home</a></li>
							<li><a href="">shop</a></li>
							<li><a href="">about us</a></li>
							<li><a href="">contact</a></li>
						</ul>
					</nav>
					<div class="footer_social">
						<ul>
							<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-reddit-alien" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<div class="copyright">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</div>
				</div>
			</div>
		</div>
	</footer>
</div>
 <script src="js/jquery.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="js/bootstrap.min.js" ></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Product</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="css/project.css">

    <!-- Load an icon library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	 <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700&display=swap" rel="stylesheet">

</head>
<body>

<div class="super_container">
<header class="header">
		<div class="header_inner d-flex flex-row align-items-center justify-content-start">
			<div class="logo"><a href="#">EW FASHION</a></div>
			<nav class="main_nav" >
				<ul>
					<li><a href="#">shop</a></li>
					<li><a href="#">about us</a></li>
					<li><a href="#">contact</a></li>
				</ul>
			</nav>
			<div class="header_content ml-auto">
				
				<div class="shopping">
						<!-- Avatar -->
					<a href="#">
						<div class="avatar">
							<img src="images/avatar.png" alt="">
						</div>
					</a>
				</div>
			</div>
		</div>
	</header>



<div class="product">
    <div class="container">
      <div class="row product_row">

        <!-- Product Image -->
        <div class="col-lg-7">
          <div class="product_image">
            <div class="product_image_large"><img src="images/beauty2.jpg" alt=""></div>
          </div>
        </div>

        <!-- Product Content -->
        <div class="col-lg-5">
          <div class="product_content">
            <div class="product_name">Head scarf</div>
            <div class="product_price">Ksh 1500</div>
          
            <!-- In Stock -->
            <div class="in_stock_container">
              <div class="in_stock in_stock_true"></div>
              <span>in stock</span>
            </div>
            <div class="product_text">
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis quam ipsum. Pellentesque consequat tellus non tortor tempus, id egestas elit iaculis. Proin eu dui porta, pretium metus vitae, pharetra odio. Sed ac mi commodo, pellentesque erat eget, accumsan justo. Etiam sed placerat felis. Proin non rutrum ligula.</p>
            </div>
            <!-- Product Quantity -->
            <div class="product_quantity_container">
              <span>Quantity</span>
              <div class="product_quantity clearfix">
                <input id="quantity_input" type="number" pattern="[0-9]*" value="1">
                <div class="quantity_buttons">
                </div>
              </div>
            </div>
            <!-- Product Size -->
            <div class="product_size_container">
              <span>Size</span>
              <div class="product_size">
                <ul class="d-flex flex-row align-items-start justify-content-start">
                  <li>
                    <input type="radio" id="radio_1" name="product_radio" class="regular_radio radio_1">
                    <label for="radio_1">XS</label>
                  </li>
                  <li>
                    <input type="radio" id="radio_2" name="product_radio" class="regular_radio radio_2" checked>
                    <label for="radio_2">S</label>
                  </li>
                  <li>
                    <input type="radio" id="radio_3" name="product_radio" class="regular_radio radio_3">
                    <label for="radio_3">M</label>
                  </li>
                  <li>
                    <input type="radio" id="radio_4" name="product_radio" class="regular_radio radio_4">
                    <label for="radio_4">L</label>
                  </li>
                  <li>
                    <input type="radio" id="radio_5" name="product_radio" class="regular_radio radio_5">
                    <label for="radio_5">XL</label>
                  </li>
                </ul>
              </div>
              <div class="button cart_button"><a href="#">add to cart</a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col text-center">
					<div class="footer_logo"><a href="#">EastWestFashion</a></div>
					<nav class="footer_nav">
					 <ul>
              <li><a href="">home</a></li>
              <li><a href="">shop</a></li>
              <li><a href="">about us</a></li>
              <li><a href="">contact</a></li>
            </ul>
					</nav>
					<div class="footer_social">
						<ul>
							<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-reddit-alien" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<div class="copyright">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</div>
				</div>
			</div>
		</div>
	</footer>
</div>
 <script src="js/jquery.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="js/bootstrap.min.js" ></script>
</body>
</html>
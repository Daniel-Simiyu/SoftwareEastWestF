<!DOCTYPE html>
<html lang="en">
<head>
<title>Cart</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="css/project.css">

    <!-- Load an icon library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	 <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700&display=swap" rel="stylesheet">

	 <style >
	 
      .whole-cart {
       
        margin: 9em;
        margin-right: 5em;
        margin-left: 5em;
        box-shadow: 
      }
      .headings {
        display: grid;
        grid-template-columns: 2fr 1fr 1fr;
      }
      .headings > h1 {
        text-align: center;
      }
      .cartcontainer {
        display: grid;
        grid-template-columns: 2fr 1fr 1fr;
        grid-auto-rows: minmax(200px, auto);
        grid-gap: 1px;
        box-shadow: 0 8px 6px -6px black;
      }
      .cartcontainer > div {
          
          background-color: #ddd;
          text-align:center;
        
        
      }
      
      .cartcontainer img {
        
        height:150px;
        max-height: 150px;
        max-width: 150px;
      }
      .price{
          padding-top: 5em;
      }
     
    

    .previous {
      background-color: #ddd;
      color: black;
    }

    .next {
      background-color: #ddd;
      color: black;
    }
    .remove{
        padding-top: 5em;
      }
      .remove button{
        padding: 5px 25px;
      background-color: rgb(231, 44, 19);
      border: none;
      border-radius: 50px;
      cursor: pointer;
      transition: all 0.3s ease 0s;
      color:white;
      }

      
    .checkout {
          padding-top: 2em;
      text-align: center;
      font-size: 18px;
    }
    .checkout button {
      padding: 5px 25px;
      background-color: cadetblue;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.3s ease 0s;
      color:white;
      font-size: 24px;
 }
     button:hover {
      background-color: black;
    }
	 </style>
</head>
<body>

<div class="super_container">
<header class="header">
		<div class="header_inner d-flex flex-row align-items-center justify-content-start">
			<div class="logo"><a href="#">EW FASHION</a></div>
			<nav class="main_nav" >
				<ul>
					<li><a href="#">shop</a></li>
					<li><a href="#">about us</a></li>
					<li><a href="#">contact</a></li>
				</ul>
			</nav>
			<div class="header_content ml-auto">
				
				<div class="shopping">
						<!-- Avatar -->
					<a href="#">
						<div class="avatar">
							<img src="images/avatar.png" alt="">
						</div>
					</a>
				</div>
			</div>

			
		</div>
	</header>

 <div class="whole-cart">
      <div class="headings">
        <h1>Item</h1>
        <h1>Price</h1>
        <h1>Remove</h1>
      </div>
      <div class="cartcontainer">
        <div class="item">
                <h3>Jersey</h3>
          			<img src="images/juve.jpg" alt="item" />
          
		        </div>
		        <div class="price">
		          <a class="previous round">&#8249;</a>
		          <span>100</span>
		          <a class="next round">&#8250;</a>
		        </div>
		        <div class="remove">
		          <button>Remove</button>
		        </div>
        <div class="item">
                <h3>Tracksuit</h3>
                <img src="images/tracksuit.jpg" alt="item" />
              </div>
              <div class="price">
                <a class="previous round">&#8249;</a>
                <span>100</span>
                <a class="next round">&#8250;</a>
              </div>
              <div class="remove">
                <button>Remove</button>
              </div>
        <div class="item">
                    <h3>Boots</h3>
                    <img src="images/boots1.jpg" alt="item" />
                  </div>
                  <div class="price">
                    <a class="previous round">&#8249;</a>
                    <span>100</span>
                    <a class="next round">&#8250;</a>
                  </div>
                  <div class="remove">
                    <button>Remove</button>
                  </div>
        
    </div>
    
  			<center>
            <div class="button cart_button"><a href="#">checkout</a></div>
          	</center>
	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col text-center">
					<div class="footer_logo"><a href="#">EastWestFashion</a></div>
					<nav class="footer_nav">
							<ul>
							<li><a href="">home</a></li>
							<li><a href="">shop</a></li>
							<li><a href="">about us</a></li>
							<li><a href="">contact</a></li>
						</ul>
					</nav>
					<div class="footer_social">
						<ul>
							<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-reddit-alien" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<div class="copyright">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</div>
				</div>
			</div>
		</div>
	</footer>
</div>
 <script src="js/jquery.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="js/bootstrap.min.js" ></script>
</body>
</html>
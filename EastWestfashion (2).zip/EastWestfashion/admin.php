<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="css/project.css">

    <!-- Load an icon library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>
<body>

<div class="super_container">
<header class="header">
		<div class="header_inner d-flex flex-row align-items-center justify-content-start">
			<div class="logo"><a href="#">EW FASHION</a></div>
			<nav class="main_nav">
				<ul>
					<li><a href="#"></a></li>
					<li><a href="#"></a></li>
					<li><a href="#"></a></li>
				</ul>
			</nav>
			<div class="header_content ml-auto">
				
				<div class="shopping">
						<!-- Avatar -->
					<a href="#">
						<div class="avatar">
							<img src="images/avatar.png" alt="">
						</div>
					</a>
				</div>
			</div>

			
		</div>
	</header>


	<div class="sidebar">
	<h4> Admin Dashboard</h4>

  <a href="#Menu">View Inventory</a>
  <a href="#contact">Manage Products</a>
  <a href="#add new item">Add New Item</a>
  <a href="#contact">Reports</a>

  
</div>

<!--Body-->

<div class="container-fluid">
	<div class="boxes">
		<h3>placeholder</h3>
	</div>

	<div>
		
	</div>

	<div>
		
	</div>>

</div>

</div>
 <script src="js/jquery.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="js/bootstrap.min.js" ></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Upload</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="css/project.css">

    <!-- Load an icon library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	 <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700&display=swap" rel="stylesheet">
<style>
   
    .main-div{
            width:25%;
            margin:0px auto;
            margin-top: 150px;
            padding:20px;
        }

        .main-div input{
            display:block;
            border:1px solid #ccc;
            border-radius: 5px;
            background: #fff;
            padding:15px;
            outline:none;
            width:100%;
            margin-bottom: 20px;
            transition: 0.3s;
            -webkit-transition: 0.3s;
            -moz-transition: 0.3s;
        }

        .main-div input:focus {
            border: 1px solid #777;
        }
        .payment{
             width:25%;
            margin:0px auto;
            margin-top: 20px;
            padding:20px;

        }
</style>
</head>
<body>

<div class="super_container">
<header class="header">
		<div class="header_inner d-flex flex-row align-items-center justify-content-start">
			<div class="logo"><a href="#">EW FASHION</a></div>
			<nav class="main_nav" >
				<ul>
                    <li><a href="#">shop</a></li>
                    <li><a href="#">about us</a></li>
                    <li><a href="#">contact</a></li>
                </ul>
			</nav>
			<div class="header_content ml-auto">
				
				<div class="shopping">
						<!-- Avatar -->
					<a href="#">
						<div class="avatar">
							<img src="images/avatar.png" alt="">
						</div>
					</a>
				</div>
			</div>

			
		</div>
	</header>

	
<div class="button extra_1_button"><a href="">Pay using </a></div>
<div class="button extra_1_button"><a href="">shop</a></div>
	
   <div class="main-div">
        <div class="details">
            <center><h3><b>1.Your details</b></h3></center>
            <p>The address will be used to send your order status updates.</p>
            <form action="#" method="POST" enctype="multipart/form-data">
            <input type="text" placeholder="Name*" name="name"/>
            <input type="text" placeholder="Phone number*" name="phone"/>
            <input type="email" placeholder="Email*" name="email"/>
            <input type="email" placeholder="Confirm Email*" name="confemail"/>
    </div> 
</form>
</div>

    <div class="payment">
        <center><h3><b>2.Payment Method</b></h3></center>
        <form>
        <p>Select your desired payment method.</p>
  <input type="radio" name="pesa" value="mpesa"> M-Pesa<br>
  <input type="radio" name="card" value="cardp"> Card Payment<br>
     </form>
 </div>

 

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col text-center">
					<div class="footer_logo"><a href="#">EastWestFashion</a></div>
					<nav class="footer_nav">
						  <ul>
                            <li><a href="">home</a></li>
                            <li><a href="">shop</a></li>
                            <li><a href="">about us</a></li>
                            <li><a href="">contact</a></li>
                        </ul>
					</nav>
					<div class="footer_social">
						<ul>
							<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-reddit-alien" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<div class="copyright">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</div>
				</div>
			</div>
		</div>
	</footer>
</div>
 <script src="js/jquery.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="js/bootstrap.min.js" ></script>
</body>
</html>
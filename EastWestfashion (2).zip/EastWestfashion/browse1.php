<!DOCTYPE html>
<html lang="en">
<head>
<title>browse</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Wish shop project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/jquery-ui-1.12.1.custom/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="styles/categories.css">
<link rel="stylesheet" type="text/css" href="styles/categories_responsive.css">


</head>
<body>

<div class="super_container">
	
	<!-- Header -->

	<header class="header">
		<div class="header_inner d-flex flex-row align-items-center justify-content-start">
			<div class="logo"><a href="#">EW FASHION</a></div>
			<nav class="main_nav">
				<ul>
					<li><a href="browse.php"></a></li>
					<li><a href="#">about us</a></li>
					<li><a href="#">contact</a></li>
				</ul>
			</nav>
			<div class="header_content ml-auto">
				
				<div class="shopping">
						<!-- Avatar -->
					<a href="#">
						<div class="avatar">
							<img src="images/avatar.png" alt="">
						</div>
					</a>
					<!-- Cart -->
					<a href="#">
						<div class="cart">
							<img src="images/cart3.png" width="25" height="25" alt="">
							<div class="cart_num_container">
								<div class="cart_num_inner">
									<div class="cart_num">0</div>
								</div>
							</div>
						</div>
					</a>
				
				
				</div>
			</div>

			<div class="burger_container d-flex flex-column align-items-center justify-content-around menu_mm"><div></div><div></div><div></div></div>
		</div>
	</header>

	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="logo menu_mm"><a href="#">EastWest</a></div>
		
		<nav class="menu_nav">
			<ul class="menu_mm">
		<li class="menu_mm"><a href="#">Log in</a></li>
        <li class="menu_mm"><a href="#">Register</a></li>
        <li class="menu_mm"><a href="#">logout</a></li> 
			</ul>
		</nav>
	</div>

		<div class="products">
			<div class="container">
			<div class="row products_container">
				<div class="col">
					
					<!-- Products -->

					<div class="product_grid">

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
		
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Woman's Long Dress</a></div>
									<div class="product_price">$45.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="" alt=""></div>
						
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">2 Piece Swimsuit</a></div>
									<div class="product_price">$35.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
							
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
					
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
						
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
							
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
						
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
					
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
						
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
						
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>
							
							<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="#" alt=""></div>

								<div class="product_content clearfix">
								<div class="product_info">
									<div class="product_name"><a href="product.php">Man Blue Jacket</a></div>
									<div class="product_price">$145.00</div>
								</div>
								<div class="product_options">
									<div class="product_buy product_option"><img src="images/cart3.png" alt=""></div>
									<div class="product_fav product_option">+</div>
								</div>
							</div>
						</div>

					</div>
				</div>
					
			</div>
		</div>
	</div>
	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col text-center">
					<div class="footer_logo"><a href="#">EastWestFashion</a></div>
					<nav class="footer_nav">
							<ul>
							<li><a href="">home</a></li>
							<li><a href="">shop</a></li>
							<li><a href="">about us</a></li>
							<li><a href="">contact</a></li>
						</ul>
					</nav>
					<div class="footer_social">
						<ul>
							<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-reddit-alien" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				<div class="copyright">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</div>
				</div>
			</div>
		</div>
	</footer>
	</div>	

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.js"></script>
<script src="plugins/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="js/categories_custom.js"></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Inventory</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="css/project.css">

    <!-- Load an icon library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	 <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700&display=swap" rel="stylesheet">

</head>
<body>

<div class="super_container">
<header class="header">
		<div class="header_inner d-flex flex-row align-items-center justify-content-start">
			<div class="logo"><a href="#">EW FASHION</a></div>
			<nav class="main_nav" >
				<ul>
					<li><a href="#">dashboard</a></li>
					<li><a href="#"></a></li>
					<li><a href="#"></a></li>
				</ul>
			</nav>
			<div class="header_content ml-auto">
				
				<div class="shopping">
						<!-- Avatar -->
					<a href="#">
						<div class="avatar">
							<img src="images/avatar.png" alt="">
						</div>
					</a>
				</div>
			</div>

			
		</div>
	</header>

	<div class="section_title_container text-center" style="margin-top: 130px !important;">
		<div class="section_title">INVENTORY</div>	
	</div>
			

    <table class="table table-hover table-responsive-sm">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Product_Id</th>
      <th scope="col">Product</th>
      <th scope="col">Image</th>
      <th scope="col">Quantity</th>
      <th scope="col">Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <td>-</td>
    <td>-</td>
    <td><img class="img-fluid img-thumbnail" width="100px" height="100px" src=""></td>
    <td>-</td>
    <td>-</td>
   </tr>
  </tbody>
</table>
	

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col text-center">
					<div class="footer_logo"><a href="#">EastWestFashion</a></div>
					<nav class="footer_nav">
					   <ul>
                            <li><a href="">home</a></li>
                            <li><a href="">shop</a></li>
                            <li><a href="">about us</a></li>
                            <li><a href="">contact</a></li>
                        </ul>
					</nav>
					<div class="footer_social">
						<ul>
							<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-reddit-alien" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<div class="copyright">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</div>
				</div>
			</div>
		</div>
	</footer>
</div>
 <script src="js/jquery.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="js/bootstrap.min.js" ></script>
</body>
</html>
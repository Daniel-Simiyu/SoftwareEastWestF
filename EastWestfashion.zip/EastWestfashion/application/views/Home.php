<!DOCTYPE html>
<html lang="en">
<head>
<title>EWhomepage</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="East West fashion project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>styles/bootstrap4/bootstrap.min.css">
<link href="<?php echo base_url();?>plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plugins/OwlCarousel2-2.2.1/animate.css">
<link href="<?php echo base_url();?>plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>styles/responsive.css">

   <style>
      *{
        margin:0px;
      }
      #float{
      margin-top:47px;
      margin-left:45px;
      margin-bottom: 50px;
      border:1px solid;
      float:left;
      width:56%;
      min-height:470px;
      background:url(images/africa2.jpg) no-repeat 0-470px;
      background-position:top;
    }
  
      #float1{
      margin-top:47px;
      margin-right:45px;
      margin-bottom: 50px;
      border:1px solid;
      color: black;
      background-color: white;
      float:right;
      width:33%;
      min-height: 470px;  
      text-align: center;
      font-family: "Times New Roman", Times, serif;
    }

       #after{
      content: "";
      display: table;
      clear: both;
    }

         footer {
        text-align: center;
        color:white;
        background-color: black;
        height: 250px;
      }
    #footer2{
        float:left;
        width:33%;
        text-align:center;
        font-size:17px;
        
        }
    #footer3 {
        float: left;
        width:33%;
        text-align:center;
        font-size:17px;
        }
    #footer4 {
        float:left;
        width:33%;
        text-align:center;
        font-size:17px;
        }

      </style>
</head>
<body>

<div class="super_container">
	
	<!-- Header -->

	<header class="header">
		<div class="header_inner d-flex flex-row align-items-center justify-content-start">
			<div class="logo"><a href="#">EW FASHION</a></div>
			<nav class="main_nav">
				<ul>
					<li><a href="#">home</a></li>
					<li><a href="#">clothes</a></li>
					<li><a href="#">accessories</a></li>
					<li><a href="#">about us</a></li>
					<li><a href="#">contact</a></li>
				</ul>
			</nav>
			<div class="header_content ml-auto">
			
				<div class="shopping">
					<!-- Cart -->
					<a href="#">
						<div class="cart">
							<img src="<?php echo base_url();?>images/cart3.png" width="30" height="30" alt="">
							<div class="cart_num_container">
								<div class="cart_num_inner">
									<div class="cart_num">0</div>
								</div>
							</div>
						</div>
					</a>
					<!-- Avatar -->
					<a href="#">
						<div class="avatar">
							<img src="<?php echo base_url();?>images/account1.png" width="40" height="40" alt="">
						</div>
					</a>
				</div>


		
			</div>
		</div>
	</header>

	<!-- Home -->

	<div class="home">
		
		<!-- Home Slider -->

		<div class="home_slider_container">
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Home Slider Item -->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(<?php echo base_url("images/mellanin2.jpg");?>"></div>
					<div class="home_slider_content">
						<div class="home_slider_content_inner">
							<div class="home_slider_subtitle">Be exclusive, Be Devine, Be yourself.</div>
							<div class="home_slider_title">Browse Collections</div>		
						</div>	
							<center>
									<div class="button extra_1_button"><a href="">shop</a></div>
									</center>
					</div>
				</div>

				<!-- Home Slider Item -->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(<?php echo base_url("images/black2.jpg");?>"></div>
					<div class="home_slider_content">
						<div class="home_slider_content_inner">
							<div class="home_slider_subtitle">Drip is forever</div>
							<div class="home_slider_title">New Men's Collection</div>
						</div>	
							<center>
									<div class="button extra_1_button"><a href="">shop</a></div>
									</center>
					</div>
				</div>

				<!-- Home Slider Item -->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(<?php echo base_url("images/black9.jpg");?>"></div>
					<div class="home_slider_content">
						<div class="home_slider_content_inner">
							<div class="home_slider_subtitle">Summer sale</div>
							<div class="home_slider_title">New Women's Collection</div>
						</div>	
							<center>
									<div class="button extra_1_button"><a href="">shop</a></div>
									</center>
					</div>
				</div>

			</div>
			
			<!-- Home Slider Nav -->

			<div class="home_slider_next d-flex flex-column align-items-center justify-content-center"><img src="<?php echo base_url();?>images/arrow_r.png" alt=""></div>

		</div>
	</div>


	<!-- Promo -->

	<div class="promo">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<div class="section_subtitle">only the best</div>
						<div class="section_title">promo prices</div>
					</div>
				</div>
			</div>
			<div class="row promo_container">

				<!-- Promo Item -->
				<div class="col-lg-4 promo_col">
					<div class="promo_item">
						<div class="promo_image">
							<img src="<?php echo base_url();?>images/black10.jpeg" alt="">
							<div class="promo_content promo_content_2">
								<div class="promo_title">-20% off</div>
								<div class="promo_subtitle">on all men sweatshirts</div>
							</div>
						</div>
						<div class="promo_link"><a href="#">Shop Now</a></div>
					</div>
				</div>

				<!-- Promo Item -->
				<div class="col-lg-4 promo_col">
					<div class="promo_item">
						<div class="promo_image">
							<img src="<?php echo base_url();?>images/beauty.jpg" alt="">
							<div class="promo_content promo_content_2">
								<div class="promo_title">-15% off</div>
								<div class="promo_subtitle">coats & jackets</div>
							</div>
						</div>
						<div class="promo_link"><a href="#">Shop Now</a></div>
					</div>
				</div>

				<!-- Promo Item -->
				<div class="col-lg-4 promo_col">
					<div class="promo_item">
						<div class="promo_image">
							<img src="<?php echo base_url();?>images/beauty2.jpg" alt="">
							<div class="promo_content promo_content_2">
								<div class="promo_title">-20% off</div>
								<div class="promo_subtitle">on head Wrap/Scarf</div>
							</div>
						</div>
						<div class="promo_link"><a href="#">Shop Now</a></div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- New Arrivals -->

	<div class="arrivals">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<div class="section_subtitle">only the best</div>
						<div class="section_title">new arrivals</div>
					</div>
				</div>
			</div>
			<div class="row products_container">

				<!-- Product -->
				<div class="col-lg-4 product_col">
					<div class="product">
						<div class="product_image">
							<img src="<?php echo base_url();?>images/black6.jpg" alt="">
						</div>
					
						<div class="product_content clearfix">
							<div class="product_info">
								<div class="product_name"><a href="">Slim fit pink suit</a></div>
								<div class="product_price">Ksh2000.00</div>
							</div>
							<div class="product_options">
								<div class="product_buy product_option"><img src="<?php echo base_url();?>images/cart3.png" alt=""></div>
								<div class="product_fav product_option">+</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Product -->
				<div class="col-lg-4 product_col">
					<div class="product">
						<div class="product_image">
							<img src="<?php echo base_url();?>images/black7.jpg" alt="">
						</div>
					
						<div class="product_content clearfix">
							<div class="product_info">
								<div class="product_name"><a href="">Woman's Long Dress</a></div>
								<div class="product_price">Ksh2500.00</div>
							</div>
							<div class="product_options">
								<div class="product_buy product_option"><img src="<?php echo base_url();?>images/cart3.png" alt=""></div>
								<div class="product_fav product_option">+</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Product -->
				<div class="col-lg-4 product_col">
					<div class="product">
						<div class="product_image">
							<img src="<?php echo base_url();?>images/black8.jpg" alt="">
						</div>
					
						<div class="product_content clearfix">
							<div class="product_info">
								<div class="product_name"><a href="">Custom made 3 piece suits</a></div>
								<div class="product_price">Ksh2700.00</div>
							</div>
							<div class="product_options">
								<div class="product_buy product_option"><img src="<?php echo base_url();?>images/cart3.png" alt=""></div>
								<div class="product_fav product_option">+</div>
							</div>
						</div>
					</div>
				</div>

			</div>
			<center>
	<div class="button extra_1_button"><a href="#">see more</a></div>
	</center>
	<br>
	</div>
	</div>

    <div id="float">
    </div>

    <div id="float1">
    <br>
  	<div class="logo" style="font-size:50px;">EW FASHION</div>
    <br>
     <p>
          East-West fashion brand strives to provide fashionable designs for various customers at great prices. 	
        </p>
    <br>
    </div>
    <br>
    <section id="after">
    </section>

	<!-- Newsletter -->

	<div class="newsletter" style="margin-bottom: 20px;">
		<div class="newsletter_content">
			<div class="newsletter_image" style="background-image:url(images/tribal4.jpg)"></div>
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="section_title_container text-center">
							<div class="section_subtitle">east-west fashion</div>
							<div class="section_title">subscribe to the ew newsletter</div>
						</div>
					</div>
				</div>

				<div class="newsletter_text" style="text-align: center;">Sign up to get our newsletter for all the latest news and trends on fashion</div>
				<div class="row newsletter_container">

					<div class="col-lg-10 offset-lg-1">
						<div class="newsletter_form_container">
							<form action="#">
								<input type="email" class="newsletter_input" required="required" placeholder="E-mail here">
								<button type="submit" class="newsletter_button">subscribe</button>
							</form>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->
 <footer>
      <div id="footer2">
      <br>
      <p style="color:;">ABOUT US</p>
      <a href="" style="color:white"> Terms & Conditions</a><br>
      <a href="" style="color:white"> Privacy Policy</a><br>
      <a href="" style="color:white"> Support</a><br>
      </div>
      
      
      <div id="footer3">
      <br>
      <p style="color:;">SOCIAL</p>
      <a href="https://www.twitter.com" style="color:white">Twitter</a><br>
      <a href="https://www.instagram.com" style="color:white">Instagram</a><br>
      <a href="https://www.facebook.com" style="color:white">Facebook</a><br>
      <a href="https://www.pinterest.com" style="color:white">Pinterest</a><br>
      <a href="https://www.googleplus.com" style="color:white">Google+</a><br>
      </div>
    

      <div id="footer4">
      <br>
      <p style="color:;">SERVICES</p>
      <a href="" style="color:white">Shop</a><br>
      <a href="" style="color:white">Login</a><br>
      <a href="" style="color:white">Register</a><br>
      </div>

   
        </footer>

	<div class="copyright">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |</div>
				</div>

	
<script src="<?php echo base_url();?>js/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url();?>styles/bootstrap4/popper.js"></script>
<script src="<?php echo base_url();?>styles/bootstrap4/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="<?php echo base_url();?>plugins/easing/easing.js"></script>
<script src="<?php echo base_url();?>plugins/parallax-js-master/parallax.min.js"></script>
<script src="<?php echo base_url();?>plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="<?php echo base_url();?>js/custom.js"></script>
</body>
</html>
<div class="row bg-dark text-white p-0">
  <div class="col-md-12 p-4">
    <footer>
      <div class="row text-center">
        <div class="col-md-3 border-right border-white">
        <p>EW-FASHIONS</p>
      </div>

      <div class="col-md-9">
        <p class="border-bottom border-white">Contact Us</p>
         <p>Tel: 0722445560</p>
          <p>Address: 666-Park Ave</p>
           <p>Email: ew-fashions@gmail.com</p>
     </div>


      </div>

      </div>    
</footer>    
  </div>
</div>




</div>

</body>
</html>
<?php 

require_once('config/config.php');


 ?>

<!DOCTYPE html>
<html>
<head>
	<title>BUTINVENT</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<script type="text/javascript" src="assets/js/bootstrap.js"></script>
	<script type="text/javascript" src="assets/js/style.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<script src="assets/js/slim.js"  type="text/javascript"></script>
	<script src="assets/js/popper.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

</head>
<body class="p-0 container-fluid">

	<!--NAVIGATION WITH SESSION-->
		<nav class="navbar navbar-dark bg-dark">
			<a href="#" class="navbar-brand">
				<img src="images/juve.jpg" height="50px" width="50px"> BUTINVENT
			</a>

			<div class=" justify-content-end">
				<a href="logout.php"><button class="btn btn-success" >Log Out</button></a>
			</div>
		</nav>
		
	<div class="container-fluid p-0">
		<div class="row">
			<div class="col-2 bg-secondary side-menu">
				<div class="hover">
					<a href="dashboard.php" >Dashboard</a>
				</div>
				<div class="hover">
					<a href="#" id="active-menu">Inventory</a>
				</div>
				<div class="hover">
					<a href="#">Transaction</a>
				</div>
				<div class="hover">
					<a href="#">Report</a>
				</div>
			</div>


		
						


</body>
</html>
<?php  
class display_ctrl extends CI_Controller 
{
	public function __construct()
	{
	parent::__construct();
	$this->load->model('display_model');
	}
   /*Display*/
	public function displaydata()
	{
	$result['data']=$this->display_model->display_records();
	$this->load->view('inventory',$result);
	}
	
}
?>
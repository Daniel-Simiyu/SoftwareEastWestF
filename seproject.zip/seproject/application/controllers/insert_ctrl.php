<?php

class insert_ctrl extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->model('insert_model');
}
function index() {

$data = array(
'Product' => $this->input->post('product'),
'Quantity' => $this->input->post('quantity'),
'Buyprice' => $this->input->post('bp'),
'Sellprice' => $this->input->post('sp'),
'Photo' => $this->input->post('pic_file')
);
//Transfering data to Model
$this->insert_model->form_insert($data);
$data['message'] = 'Data Inserted Successfully';
//Loading View
$this->load->view('inventory', $data);
}
}

?>

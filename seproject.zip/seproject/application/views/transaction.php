<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>ButInvent</title>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
	<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
	<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.bundle.js');?>"></script>
	<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>
	<script src="https://kit.fontawesome.com/23412c6a8d.js"></script>

</head>
<body>

	<!--div class="p-0 m-0 navigation row">
		<div class="col-md-12 col-xs-12 col-sm-12">
			
			<ul class="nav navigation-items">
				<li class="nav-item text-white">BUTINVENT</li>
				<li></li>
				<div class="dropdown">
 				<button class="btn btn-danger">Session Name</button>
  				<div class="dropdown-content">
  				<P>Position</P>
    			<a href="#">Log Out</a>
  				</div>
			</div> 
				</div>
			</ul>
			
		</div>
	</div-->

	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		  <a class="navbar-brand" href="#">EW-FASHIONS</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarText">
		    <ul class="navbar-nav mr-auto">
		      <li class="nav-item active">
		        <a class="nav-link" href="#">Home<span class="sr-only">(current)</span></a>
		      </li>

		      <li class="nav-item">
		        <a class="nav-link" href="#">Cart</a>
		      </li>
		     	<div class="dropdown">
 				<li class="nav-item">
 				 <a class="nav-link" href="#">Contact Us</a>
 				</li>
  				<div class="dropdown-content">
  				<p>Tel: 0712345678</p>
  				<p>Address: CBD-00200</p>
  				<p>Email: ewfasshions@hotmail.com</p>
  				</div>
			</div> 
		    </ul>
		   		<div class="dropdown">
 				<button class="btn btn-danger">Session Name</button>
  				<div class="dropdown-content">
  				<P>Position</P>
    			<a href="#">Log Out</a>
  				</div>
			</div> 
				</div>
		  </div>
</nav>
	
	<div class="container-fluid row">
		<div class="col-md-2 side bg-secondary">
			<ul class="list-group list-group-flush">
			  <li class="list-group-item">Dashboard</li>
			  <li class="list-group-item">Traansactions</li>
			  <li class="list-group-item">Reports</li>
			</ul>
		</div>

		<div class="col-md-10 p-2">

			<div class="card">
				<div class="card-header text-white text-center bg-dark"> 
					M-PESA TRANSACTIONS
				</div>

				<div class="card-body">
					
			<table class="table table-hover table-responsive-sm">
  <thead class="thead-dark">
    <tr>
      <th scope="col">T_ID</th>
      <th scope="col">Item</th>
      <th scope="col">Message</th>
      <th scope="col">Amount</th>
      <th scope="col">Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <td>1</td>
    <td>Boots</td>
    <td>Confirmed You have recieved 5000 from fibfvwbagsfdwfda kajjbscksbddowf Balance 10000</td>
    <td>5000</td>
    <td>09/09/2019</td>
   </tr>

   <tr>
    <td>2</td>
    <td>Boots</td>
    <td>Confirmed You have recieved 5000 from fibfvwbagsfdwfda kajjbscksbddowf Balance 10000</td>
    <td>5000</td>
    <td>09/09/2019</td>
   </tr>

   <tr>
    <td>3</td>
    <td>Boots</td>
    <td>Confirmed You have recieved 5000 from fibfvwbagsfdwfda kajjbscksbddowf Balance 10000</td>
    <td>5000</td>
    <td>09/09/2019</td>
   </tr>
  </tbody>
			
</table>
					 
			</div>
		</div>
		<div class="col-md-10 p-2">
			
		</div>
		<div class="card">
				<div class="card-header text-white text-center bg-dark"> 
					CASH TRANSACTIONS
				</div>

				<div class="card-body">
					
			<table class="table table-hover table-responsive-sm">
  <thead class="thead-dark">
    <tr>
      <th scope="col">T_ID</th>
      <th scope="col">Item</th>
      <th scope="col">Amount</th>
      <th scope="col">Confirmed By</th>
      <th scope="col">Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <td>2</td>
    <td>Boots</td>
    <td>5000</td>
    <td>Ezekiel Mwangi</td>
    <td>09/09/2019</td>
   </tr>

   <tr>
    <td>3</td>
    <td>Boots</td>
    <td>5000</td>
    <td>Ezekiel Mwangi</td>
    <td>09/09/2019</td>
   </tr>
				</div>

			</div>
</table>			 
			</div>
		</div>
			

	</div>


</body>
</html>
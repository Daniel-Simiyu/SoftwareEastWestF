<!DOCTYPE html>
<html>
<head>
<title>Delete Data From Database Using CodeIgniter</title>
<!--=========== Importing Google fonts ===========-->
<link href='http://fonts.googleapis.com/css?family=Marcellus' rel='stylesheet' type='text/css'>
<link href="<?php echo base_url()?>./css/delete.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="container">
<div id="wrapper">
<h1>Delete Data</h1>
<div id="menu">	
<p>Click On Menu</p>
<!--====== Displaying Fetched Names from Database in Links ========-->
<ol>
<?php foreach ($items as $item): ?>
<li><a href="<?php echo base_url() . "index.php/delete_ctrl/show_item_id/" . $item->Product_Id; ?>"><?php echo $item->Product; ?></a>
</li><?php endforeach; ?>
</ol>
</div>
<div id="detail">
<!--====== Displaying Fetched Details from Database ========-->
<?php foreach ($single_item as $item): ?>
<p>Item Details</p>
<?php echo $item->Product_Id; ?>
<?php echo $item->Product; ?>
<?php echo $item->Quantity; ?>
<?php echo $item->Buyprice; ?>
<?php echo $item->Sellprice; ?>
<?php echo $item->Photo; ?>
<!--====== Delete Button ========-->
<a href="<?php echo base_url() . "index.php/delete_ctrl/delete_item_id/" . $item->Product_Id; ?>">
<button>Delete</button></a>
<?php endforeach; ?>
</div>
</div>
</div>
</body>
</html>
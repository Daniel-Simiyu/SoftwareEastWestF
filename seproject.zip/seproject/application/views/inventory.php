<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Insertdata</title>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/insert.css');?>">
	<link href='http://fonts.googleapis.com/css?family=Marcellus' rel='stylesheet' type='text/css'/>
	<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
	<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.bundle.js');?>"></script>
	<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>
	<script src="https://kit.fontawesome.com/23412c6a8d.js"></script>

</head>
<body>

	<!--div class="p-0 m-0 navigation row">
		<div class="col-md-12 col-xs-12 col-sm-12">
			
			<ul class="nav navigation-items">
				<li class="nav-item text-white">BUTINVENT</li>
				<li></li>
				<div class="dropdown">
 				<button class="btn btn-danger">Session Name</button>
  				<div class="dropdown-content">
  				<P>Position</P>
    			<a href="#">Log Out</a>
  				</div>
			</div> 
				</div>
			</ul>
			
		</div>
	</div-->

	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		  <a class="navbar-brand" href="#">EW-FASHIONS</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarText">
		    <ul class="navbar-nav mr-auto">
		      <li class="nav-item active">
		        <a class="nav-link" href="#">Home<span class="sr-only">(current)</span></a>
		      </li>

		      <li class="nav-item">
		        <a class="nav-link" href="#">Cart</a>
		      </li>
		     	<div class="dropdown">
 				<li class="nav-item">
 				 <a class="nav-link" href="#">Contact Us</a>
 				</li>
  				<div class="dropdown-content">
  				<p>Tel: 0712345678</p>
  				<p>Address: CBD-00200</p>
  				<p>Email: ewfasshions@hotmail.com</p>
  				</div>
			</div> 
		    </ul>
		   		<div class="dropdown">
 				<button class="btn btn-danger">Session Name</button>
  				<div class="dropdown-content">
  				<P>Position</P>
    			<a href="#">Log Out</a>
  				</div>
			</div> 
				</div>
		  </div>
</nav>
	
	<div class="container-fluid row">
		<div class="col-md-2 side bg-secondary">
			<ul class="list-group list-group-flush">
			  <li class="list-group-item">Dashboard</li>
			  <li class="list-group-item">Traansactions</li>
			  <li class="list-group-item">Reports</li>
			  <li class="list-group-item"><a href="<?php echo base_url('application/views/delete_view.php');?>" style="text-decoration: none; color: black;">Delete</a></li>
			</ul>
		</div>



<table width="800" border="1" cellspacing="5" cellpadding="5">
  <tr style="background:#CCC">
    <th>ID</th>
    <th>Item</th>
    <th>Image</th>
    <th>Quantity</th>
	<th>Buying Price</th>
	<th>Selling Price</th>
  </tr>

 
  <?php 
  if( !empty($results) ) {
    foreach($results as $row) {

  echo "<tr>";
  echo "<td>".$row->Product_Id."</td>";
  echo "<td>".$row->Product."</td>";
  echo "<td>".$row->Photo."</td>";
  echo "<td>".$row->Quantity."</td>";
  echo "<td>".$row->Buyprice."</td>";
  echo "<td>".$row->Sellprice."</td>";
  echo "</tr>";
  }
}
 ?>
</table>


<div class="main-div">
<?php echo form_open('insert_ctrl'); ?>
<center>
<h2>Add Products</h2><hr/>
</center>
<?php if (isset($message)) { ?>
<CENTER><h3 style="color:green;">Data inserted successfully</h3></CENTER><br>
<?php } ?>
<?php echo form_label('Product '); ?> <?php echo form_error('product'); ?><br />
<?php echo form_input(array('id' => 'product', 'name' => 'product')); ?><br />

<?php echo form_label('Quantity '); ?> <?php echo form_error('quantity'); ?><br />
<?php echo form_input(array('id' => 'quantity', 'name' => 'quantity')); ?><br />

<?php echo form_label('Buying Price'); ?> <?php echo form_error('bp'); ?><br />
<?php echo form_input(array('id' => 'bp', 'name' => 'bp')); ?><br />

<?php echo form_label('Selling Price'); ?> <?php echo form_error('sp'); ?><br />
<?php echo form_input(array('id' => 'sp', 'name' => 'sp')); ?><br />


    <label for="pic_file">Select Image</label>
    <input type="file" name="pic_file">
  
<br>
<?php echo form_submit(array('id' => 'submit', 'value' => 'Submit')); ?>
<?php echo form_close(); ?><br/>
<div id="fugo">

</div>
</div>
</body>
</html>
			




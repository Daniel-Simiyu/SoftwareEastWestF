<?php
class display_model extends CI_Model 
{
   /*View*/
	function display_records()
	{
	$results = array();
    $query = $this->db->get();
	$query=$this->db->query("select * from items");
		if($query->num_rows() > 0) {
        $results = $query->result();
    	}
    	return $results;
	}
	
} 
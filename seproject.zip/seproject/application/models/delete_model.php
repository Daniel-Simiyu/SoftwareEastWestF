<?php
class delete_model extends CI_Model{
// Function to select all from table name students.
function show_items(){
$query = $this->db->get('items');
$query_result = $query->result();
return $query_result;
}
// Function to select particular record from table name students.
function show_item_id($data){
$this->db->select('*');
$this->db->from('items');
$this->db->where('Product_Id', $data);
$query = $this->db->get();
$result = $query->result();
return $result;
}
// Function to Delete selected record from table name students.
function delete_item_id($id){
$this->db->where('Product_Id', $id);
$this->db->delete('items');
}
}
?> 